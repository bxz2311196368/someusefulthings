@API(apiVersion = "9.0.0", owner = "Mekanism", provides = "MekanismAPI|energy")
package mekanism.api.energy;
import net.minecraftforge.fml.common.API;


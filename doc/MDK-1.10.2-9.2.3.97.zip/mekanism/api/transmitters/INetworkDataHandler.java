package mekanism.api.transmitters;

public interface INetworkDataHandler
{
	public String getNeededInfo();

	public String getStoredInfo();

	public String getFlowInfo();
}
